<?php
    /**
     * Nombre: Juda Alector Vallejo Herrera
     * Descripción: Limpia la varaible session, para eliminar 
     *              la sesión que está en curso. 
     * Fecha: 26 de Marzo del 2018
     */
    unset($_SESSION["id"]);
?>