<?php

    function startSessionWith($usuario){
        echo session_start();        
        $_SESSION["id"] = $usuario["id"];
        $_SESSION["nombre"] = $usuario["nombre"];
        $_SESSION["correo"] = $usuario["correo"];
        $_SESSION["tipo"] = $usuario["tipo"];

        switch($usuario["tipo"]){
            case 1: header("Location: ../../app/master/index."); break;
            case 2: header("Location: ../../app/admin/index.html"); break;
            case 3: header("Location: ../../app/index.html"); break;
            default: header("Location: /app/server-errors/no_login.html"); break;
        }
    }

    /**
     * Nombre: Juda Alector Vallejo Herrera
     * Descripción: Revizar sí un usario está accediendo a una 
     *              página permitida o a su tipo de usuario.
     * Fecha:  25 de Mayo del 2018
     * 
     */
    function checkPermission($type){
        $permission = 0;
        if(strpos($_SERVER["REQUEST_URI"], "app/admin/")){
            $permission = ($type == 2);
        }else if (strpos($_SERVER["REQUEST_URI"], "app/master/")){
            $permission = ($type == 1);
        }else if(strpos($_SERVER["REQUEST_URI"], "app/usuario/")){
            $permission = ($type == 3);
        }
        return $permission;
    }


?>