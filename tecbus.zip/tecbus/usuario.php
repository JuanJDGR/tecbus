<?php 
    include '../../php/login/session.php';
    session_start();
    if(!checkPermission($_SESSION['tipo'])){
      header("Location: ../server-errors/error_404.html");
    }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tecbus</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">

  </head>

  <body>

    <h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">Bienvenidos  A Tecbus</span>
      <span class="site-heading-lower">Pagobus</span>
    </h1>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="#">Menu</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="index.html">Inicio
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="mapa.html">Mapa</a>
            </li>
            <li class="nav-item active px-lg-4">
                <a class="nav-link text-uppercase text-expanded" href="rutas.html">Rutas</a>
              </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.html">Informacion</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="loggin.html">Loggin</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <section class="page-section clearfix">

      <div id="main-contenedor" class="container max-width">
    <!-- Barra de navegación -->
    <nav class="navbar navbar-expand-sm navbar-expand-md navbar-expand-lg navbar-light bg-light">
      <div>
      <input type="image" alt="Home" src="../../img/logo.png" id="bar-logo">
      </div>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
        </ul>
        <p id="bar-usuario-nombre"><i><?php echo $_SESSION["nombre"]; ?></p>
          <div id="preview">
            <?php 
              $foto = '../../resources/profile-img/img'.$_SESSION["id"].'.jpg';
              if (file_exists($foto)) {
                $foto = "img".$_SESSION["id"].".jpg";
              } else {
                $foto = "user.png";
              }
              echo ("<img src='../../resources/profile-img/".$foto."' id='bar-usuario-imagen'></img>");
            ?>
        </div>
      </div>
    </nav>

    <div class="container-fluid row" style="margin-top:30px">
      <!-- Contenedor lateral izquierdo -->
      <div id="izq-contenedor" class="col-sm-4 col-md-3 col-lg-2" align="center">
          <button id="btn-registrar" type="button" class="btn boton-opcion">Actualizar datos
          </button>
          <button id="btn-solicitabaja" type="button" class="btn boton-opcion">Solicitar baja
          </button>
          <button id="btn-Vestado" type="button" class="btn boton-opcion">Ver estado
          </button>
          <button id="btn-salir" type="button" class="btn boton-opcion">Salir
          </button>
          

      </div>
      <!-- Contenedor lateral derecho -->
      <div id="der-contenedor" class="col-sm-8 col-md-7 col-lg-9" >
        <div class="jumbotron jumbotron-fluid">
          <div class="container">
            <h3 class="display-4">Bienvenido</h1>
              <p class="lead">En la Dirección General de Movilidad, asumimos el compromiso de fomentar, promover y gestionar la movilidad no motorizada como medio de transporte público, en específico la bicicleta.</p>
              <hr class="my-4">
              <p>Con el sistema de pagobús podrás ver, revisar y subir tus datos para poder tramitar tu tarjeta pagobús.</p>
            </div>
          </div>
        </div>

      </div>
    </div>
     <script type="text/javascript" src="../../js/usuario/navegacion.js"></script>
     <script type="text/javascript" src="../../js/usuario/Modal.js"></script>

  </body>

</html>