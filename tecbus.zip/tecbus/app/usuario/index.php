<?php 
    include '../../php/login/session.php';
    session_start();
    if(!checkPermission($_SESSION['tipo'])){
      header("Location: ../server-errors/error_404.html");
    }
?>
<!DOCTYPE html>
<html>

<head>
  <title>Usuario</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/ico" href="../../img/main_ico.ico">
  <link rel="stylesheet" type="text/css" href="../../lib/animate.css">
  <link rel="stylesheet" type="text/css" href="../../css/global.css">
  <link rel="stylesheet" type="text/css" href="../../lib/bootstrap-4.0.0/dist/css/bootstrap.min.css">
  <script src="../../lib/jquery-3.3.1.js"></script>
  <script src="../../lib/popper.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>
  <script src="../../lib/node_modules/sweetalert/dist/sweetalert.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">

</head>
<body>
<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-4">Bienvenidos  A Tecbus </span>
      <span class="site-heading-lower">Pagobus</span>
    </h1>
    <section class="page-section clearfix">

  <div id="main-contenedor" class="container max-width">
    <!-- Barra de navegación -->
    <nav class="navbar navbar-expand-sm navbar-expand-md navbar-expand-lg navbar-light bg-light">
      <div>
      <input type="image" alt="Home" src="../../img/bg2.jpg" id="bar-logo">
      </div>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
        </ul>
        <p id="bar-usuario-nombre"><i><?php echo $_SESSION["nombre"]; ?></p>
          <div id="preview">
            <?php 
              $foto = '../../resources/profile-img/img'.$_SESSION["id"].'.jpg';
              if (file_exists($foto)) {
                $foto = "img".$_SESSION["id"].".jpg";
              } else {
                $foto = "user.png";
              }
              echo ("<img src='../../resources/profile-img/".$foto."' id='bar-usuario-imagen'></img>");
            ?>
        </div>
      </div>
    </nav>

    <div class="container-fluid row" style="margin-top:30px">
      <!-- Contenedor lateral izquierdo -->
      <div id="izq-contenedor" class="col-sm-4 col-md-3 col-lg-2" align="center">
          <button id="btn-registrar" type="button" class="btn boton-opcion">Actualizar datos
          </button>
          <button id="btn-tarjeta" type="button" class="btn boton-opcion">Tarjeta
          </button>
          <button id="btn-solicitabaja" type="button" class="btn boton-opcion">Solicitar baja
          </button>
          <button id="btn-Vestado" type="button" class="btn boton-opcion">Ver estado
          </button>
          <button id="btn-salir" type="button" class="btn boton-opcion">Salir
          </button>
          

      </div>
      <!-- Contenedor lateral derecho -->
      <section class="page-section clearfix">

      
      <div class="container">
        <div class="intro">
          <img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="img/intro.jpg" alt="">
          <div class="intro-text left-0 text-center bg-faded p-5 rounded">
            <h2 class="section-heading mb-4">
              <span class="section-heading-upper">Tabla de saldo</span>
              <span class="section-heading-lower"></span>
            </h2>
            </div>
          </div>
        </div>
        </section>
      </div>
    </div>
     <script type="text/javascript" src="../../js/usuario/navegacion.js"></script>
     <script type="text/javascript" src="../../js/usuario/Modal.js"></script>
  </body>
  </html>