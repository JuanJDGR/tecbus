<?php 
    include '../../php/login/session.php';
    session_start();
    if(!checkPermission($_SESSION['tipo'])){
      header("Location: ../server-errors/error_404.html");
    }
?>
<!DOCTYPE html>
<html>


<head>
  <title>Actualizar Datos</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/ico" href="../../img/main_ico.ico">
  <link rel="stylesheet" type="text/css" href="../../lib/animate.css">
  <link rel="stylesheet" type="text/css" href="../../css/global.css">
  <link rel="stylesheet" type="text/css" href="../../css/usuario/main.css">
  <link rel="stylesheet" type="text/css" href="../../lib/bootstrap-4.0.0/dist/css/bootstrap.min.css">
  <script src="../../lib/jquery-3.3.1.js"></script>
  <script src="../../lib/popper.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>
  <script src="../../lib/node_modules/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body>


  <div id="main-contenedor" class="container max-width">
    <!-- Barra de navegación -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div>
        <input type="image" alt="Home" src="../../img/bg1.jpg" id="bar-logo">
      </div>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">

        </ul> 
        <p id="bar-usuario-nombre"><i><?php echo $_SESSION["nombre"]; ?></i></p>
        <a>
           <div id="preview">
            <?php 
              $foto = '../../resources/profile-img/img'.$_SESSION["id"].'.jpg';
              if (file_exists($foto)) {
                $foto = "img".$_SESSION["id"].".jpg";
              } else {
                $foto = "user.png";
              }
              echo ("<img src='../../resources/profile-img/".$foto."' id='bar-usuario-imagen'></img>");
            ?>
        </div>
        </a>
      </div>
    </nav>


    <div class="container-fluid row" style="margin-top:30px">
      <!-- Contenedor lateral izquierdo -->
      <div id="izq-contenedor" class="col-md-2">
        <button id="btn-inicio" type="button" class="btn boton-opcion">Pagina Principal
        </button>
        <button id="btn-solicitabaja" type="button" class="btn boton-opcion">Solicitar baja
        </button>
        <button id="btn-Vestado" type="button" class="btn boton-opcion">Ver estado
        </button>
        <button id="btn-salir" type="button" class="btn boton-opcion">Salir
        </button>

      </div>
      <!-- Contenedor lateral derecho -->
      <div id="der-contenedor" class="col-md-9" data-id-usuario="<?php echo $_SESSION['id']; ?>">
        <h3 class="container display-7 text-center mt-3">Tarjeta </h3>

        <form id="form-registro-usuario" class="mb-3" method="POST" action="../../php/usuario/registrarUsuario.php"  enctype="multipart/form-data">

          <!-- Imagen de Usuario -->
         
          <div class="custom-file col-md-4 offset-md-4 mb-3">
            <input id="input-foto" name="input-foto" type="file"  accept=".jpg,.jpeg,.png" onchange="readImage()" style="display: none">
          </div>
          <!-- Identifacador este debe ser rellenado por la variable $_SESSION -->
          <div class="form-group col-md-3 offset-md-1">
              <label>No. identificación</label>
              <input id="input-id" class="form-control"  type='number' name="input-id" <?php echo 'value="'.$_SESSION['id'].'"'; ?></input>
            </div>

          <!-- Nombre -->
          <div class="form-group col-md-10 offset-md-1">
            <label>Nombre</label>
            <input id="input-nombre" class="form-control " placeholder="Nombre" type='text' name="input-nombre" autocomplete="given-name"></input>
          </div>
          
          <!-- Nombre -->
          <div class="form-group col-md-10 offset-md-1">
            <label>Folio de la tarjeta </label>
            <input id="input-nombre" class="form-control " placeholder="P1708F6F98223" type='text' name="input-nombre" autocomplete="given-name"></input>
          </div>

          <!-- Nombre -->
          <div class="form-group col-md-10 offset-md-1">
            <label>Tipo de la baja </label>
            <input id="input-nombre" class="form-control " placeholder="Permanente O Temporal" type='text' name="input-nombre" autocomplete="given-name"></input>
          </div>

          <!-- Nombre -->
          <div class="form-group col-md-10 offset-md-1">
            <label>Motivo de la baja </label>
            <input id="input-nombre" class="form-control " placeholder="Motivo" type='text' name="input-nombre" autocomplete="given-name"></input>
          </div>
          
          

          
          <button id="btn-aceptar" type="submit" class="btn btn-success col-md-2 offset-md-5" enable>Guardar cambios  </button>
        </form>
      </div>
    </div>
  </div>
  <script src="../../js/Actualizar_foto.js" type="text/javascript"></script>
  <script src="../../js/usuario/registrarUsuario.js" type="text/javascript"></script>
  <script type="text/javascript" src="../../js/usuario/navegacion.js"></script>
  <script type="text/javascript" src="../../js/usuario/Modal.js"></script>
  <script src="../../js/usuario/AutocompletarForm.js"></script> 
</body>
</html>