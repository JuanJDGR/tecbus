<?php       
abstract class conexion {
    private static $gestor;
    private static $servidor;
    private static $usuario;
    private static $contraseña;
    private static $db;
    private static $puerto;
    public  $obj_cone;

    function _construct(){
   self::$gestor= "mysql";
   self::$servidor= "localhost";
   self::$usuario= "root";
   self::$contraseña= "root";
   self::$db= "tecbus";
   self::$puerto= "3307";

    }

    function conectar(){
try{
$this->obj_cone= new PDO(self::$gestor.'host'=self::$servidor. 'dbname'=self::$db.';port'=self::$puerto,self::$usuario,self::$contraseña);
return true;

}
catch(PDOException $e){
return false;

}
    }
function __destruct(){

unset($this );
$this->obj_cone=null;
}
}

?>
