/*
*  Nombre: Juan Pablo Gallardo Ochoa 
*  Descripción: Archivo de js, para registrar un nuevo usuario en la BD
*  Fecha: 18 de Mayo 2018
*/

